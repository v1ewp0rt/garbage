#include "include/Game.h"

Game game; // Inicializo el juego
int main() { game.main_loop(); } // Ejecuto el bucle principal